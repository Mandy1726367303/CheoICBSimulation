import numpy as np
from scipy.special import comb
from copy import deepcopy
import matplotlib.pyplot as plt
import math

mutations = {}
sumA = {}
r1 = 1
r2 = 0.5
mu1 = 0.5
mut_rate = -math.log(1-mu1,math.e)
db = 0
cutoff = 0
therapy = 65
escape_rate = 1e-5
mu2 = 0.6
mu3 = 0.05
KN = 0.9
KI = 0.9
Kd = 0.6
KE = 0.6
M = 5
d = 0.5
def rate_func(*args):
    return 0.00001


def sel_strength(N,A,I):
    return -0.8


def birth_rate(cells,N,A,I):
    return sum([cell.birth_cell() for cell in cells]) / len(cells)


def total_death_rate(cells, N, A, I):
    ss = sel_strength(N, A, I)
    return sum([cell.death_rate(ss) for cell in cells]) / len(cells)


class Cell:
    def __init__(self, mutation=[], cell_type=None, escape_type=None):
        self.mutation = mutation
        self.cell_type = cell_type
        self.escape_type = escape_type

    def birth_cell(self):
        escape_type = self.escape_type
        cell_type = self.cell_type
        if cell_type == 1 or escape_type == 2:
            return r2
        else: return r1

    def sumA(self):
        mutation = self.mutation
        suma = sum([mutations[i][0] for i in mutation])
        return suma

    def death_rate(self, s):
        sumA = self.sumA()
        escape_type = self.escape_type
        cell_type = self.cell_type
        if system.t[-1] < therapy:
            if sumA < cutoff or escape_type == 2:
                return db
            else:
                if cell_type == 1:
                    return d
                else:
                    return db
        else:
            if escape_type == 2:
                return r2*KE*(1-np.exp(-M))
            else:
                if sumA < cutoff or cell_type == 2:
                    return r1*KN * (1 - np.exp(-M))
                if cell_type == 1:
                    return r2*KI*(1-np.exp(-M)) + d*(1-Kd*(1-np.exp(-M)))


class Reaction:
    def __init__(self, rate=0., num_lefts=None, num_rights=None, index=None):
        self.rate = rate
        assert len(num_lefts) == len(num_rights)
        self.num_lefts = np.array(num_lefts)  # 反应前各个反应物的数目
        self.num_rights = np.array(num_rights)  # 反应后各个反应物的数目
        self.num_diff = self.num_rights - self.num_lefts  # 改变数
        self.index = index

    def combine(self, n, s):  # 算组合数
        return np.prod(comb(n, s))

    def propensity(self, n, cells, N, A, I):  # 算反应倾向函数
        return self.rate(cells, N, A, I) * self.combine(n, self.num_lefts)


class System:  # 封装的类，代表多个化学反应构成的系统
    def __init__(self, num_elements, inits=None, N=10, A=0, I=0, max_cell=100000):
        assert num_elements > 0
        self.num_elements = num_elements  # 系统内的反应物的类别数
        self.reactions = []  # 反应集合
        self.N = N
        self.A = A
        self.I = I
        self.log = {'N': [N], 'A': [A], 'I': [I]}
        self.max_cell = max_cell
        if inits is None:
            self.n = [np.ones(self.num_elements)]
            self.cells = [Cell()]

        else:
            self.n = [np.array(inits)]  # 反应物数目，n[0]是初始数目
            self.cells = [Cell() for _ in range(int(self.n[0][0]))]

    def add_reaction(self, rate=0., num_lefts=None, num_rights=None, index=None):
        assert len(num_lefts) == self.num_elements
        assert len(num_rights) == self.num_elements
        self.reactions.append(Reaction(rate, num_lefts, num_rights, index=index))

    def evolute(self, steps):  # 模拟演化

        self.t = [0]  # 时间轨迹，t[0]是初始时间

        def mutation(cell):
            new_mut_num = round(np.random.poisson(mut_rate))
            new_mut_id = [max(mutations.keys(), default=0) + i + 1 for i in range(new_mut_num)]
            anti_val = [np.random.exponential(0.2) for _ in range(new_mut_num)]
            for i, new_mut in enumerate(new_mut_id):
                mutations.update({new_mut: [anti_val[i], 0]})
            cell.mutation += new_mut_id
            return cell, new_mut_id

        def proliferate():
            divide_cell = np.random.choice(self.cells)
            dau1, new_mut1 = mutation(deepcopy(divide_cell))
            dau2, new_mut2 = mutation(deepcopy(divide_cell))

            for mut in new_mut1 + new_mut2:
                mutations[mut][1] += 1
            for mut in divide_cell.mutation:
                mutations[mut][1] += 1

            if np.random.rand() < escape_rate:
                dau1.escape_type = 2
            if np.random.rand() < escape_rate:
                dau2.escape_type = 2
            if divide_cell.escape_type == 2:
                dau1.escape_type = 2
                dau2.escape_type = 2

            if divide_cell.sumA() < cutoff:
                self.N -= 1
                if dau1.sumA() < cutoff:
                    self.N += 1
                else:
                    if np.random.rand() < mu2:
                        dau1.cell_type = 1
                        self.I += 1
                        if np.random.rand() < mu3:
                            dau1.cell_type = 2
                            self.I -= 1
                            self.A += 1
                    else:
                        dau1.cell_type = 2
                        self.A += 1

                if dau2.sumA() < cutoff:
                    self.N += 1
                else:
                    if np.random.rand() < mu2:
                        dau2.cell_type = 1
                        self.I += 1
                        if np.random.rand() < mu3:
                            dau2.cell_type = 2
                            self.I -= 1
                            self.A += 1
                    else:
                        dau2.cell_type = 2
                        self.A += 1


            else:
                if divide_cell.cell_type == 2:
                    self.A -= 1
                if divide_cell.cell_type == 1:
                    self.I -= 1
                if dau1.sumA() < cutoff:
                    self.N += 1
                else:
                    if np.random.rand() < mu2:
                        dau1.cell_type = 1
                        self.I += 1
                        if np.random.rand() < mu3:
                            dau1.cell_type = 2
                            self.I -= 1
                            self.A += 1
                    else:
                        dau1.cell_type = 2
                        self.A += 1

                if dau2.sumA() < cutoff:
                    self.N += 1
                else:
                    if np.random.rand() < mu2:
                        dau2.cell_type = 1
                        self.I += 1
                        if np.random.rand() < mu3:
                            dau2.cell_type = 2
                            self.I -= 1
                            self.A += 1
                    else:
                        dau2.cell_type = 2
                        self.A += 1

            self.cells.remove(divide_cell)
            self.cells.append(dau1)
            self.cells.append(dau2)

        def compete():

            deathp = np.array([1 for cell in self.cells])
            deathp = deathp / sum(deathp)
            death_cell = np.random.choice(self.cells, p=deathp)
            if death_cell.sumA() < cutoff:
                self.N -= 1
            else:
                if death_cell.cell_type == 1:
                    self.I -= 1
                if death_cell.cell_type == 2:
                    self.A -= 1
            for mut in death_cell.mutation:
                mutations[mut][1] -= 1
            self.cells.remove(death_cell)

        def death():
            s = sel_strength(self.N, self.A, self.I)
            deathp = np.array([cell.death_rate(s) for cell in self.cells])
            deathp = deathp / sum(deathp)
            death_cell = np.random.choice(self.cells, p=deathp)
            if death_cell.sumA() < cutoff:
                self.N -= 1
            else:
                if death_cell.cell_type == 1:
                    self.I -= 1
                if death_cell.cell_type == 2:
                    self.A -= 1
            for mut in death_cell.mutation:
                mutations[mut][1] -= 1
            self.cells.remove(death_cell)

        for i in range(steps):
            A = np.array([rec.propensity(self.n[-1], self.cells, self.N, self.A, self.I)
                          for rec in self.reactions])  # 算每个反应的倾向函数
            A0 = A.sum()
            A /= A0  # 归一化得到概率分布
            t0 = -np.log(np.random.random()) / A0  # 按概率选择下一个反应发生的间隔
            self.t.append(self.t[-1] + t0)
            react = np.random.choice(self.reactions, p=A)  # 按概率选择其中一个反应发生

            self.n.append(self.n[-1] + react.num_diff)
            switch = {0: proliferate, 1: death, 2: compete}
            switch.get(react.index)()
            self.log['N'].append(self.N)
            self.log['A'].append(self.A)
            self.log['I'].append(self.I)
            if system.n[-1] < 1 or system.t[-1] > 85:
                break


system = System(1, np.array([10]), max_cell=100000)
system.add_reaction(birth_rate, [1], [2], index=0)
system.add_reaction(total_death_rate, [1], [0], index=1)
system.add_reaction(rate_func, [2], [1], index=2)
system.evolute(100000000)
pop_size = np.array(system.n).reshape(1, -1)[0]
N = system.log['N']
sumA = np.array([i.sumA() for i in system.cells])
A = system.log['A']
I = system.log['I']
np.savetxt('IHeM_Chemo_P.txt', pop_size, fmt='%d', delimiter=',')
np.savetxt('IHeM_Chemo_A.txt', A, fmt='%d', delimiter=',')
np.savetxt('IHeM_Chemo_I.txt', I, fmt='%d', delimiter=',')
np.savetxt('IHeM_Chemo_t.txt', system.t, delimiter=',')
np.savetxt('IHeM_Chemo_sumA.txt', sumA, delimiter=',', fmt='%f')
mutation_num = np.array([0, 0])
for i in mutations:
    mutation_num = np.vstack((mutation_num, [mutations[i][0], mutations[i][1]]))
mutation_num = mutation_num[1:, :]
np.savetxt('IHeM_Chemo_m.txt', mutation_num)

